import React from 'react';
import {
  StyleSheet,
  Button,
  View,
  SafeAreaView,
  Text,
  Alert,
  Image,
  Pressable,
  ImageBackground,
  
} from 'react-native';

const Separator = () => <View style={styles.separator} />;

const App = () => (
  //<SafeAreaView style={styles.container}>

  <View style={styles.blackbar}> 
    

    <View style={styles.row} >
   

   
    <View style={styles.column}>
      <Pressable
       onPress={() => {Alert.alert("this will go to Dashboard Center")}}
       style={( {pressed} ) => 
       {return {opacity: pressed? 0.5 : 1}} } >
      <Image style={styles.profile_image} source = {require("./assets/Dashboard.png")} />
      </Pressable>
      <Text style={styles.navtext}>Dashboard</Text>      
    </View>
    
    <View style={styles.column}>
      <Pressable
       onPress={() => {Alert.alert("this will go to  Rewards")}}
       style={( {pressed} ) => 
       {return {opacity: pressed? 0.5 : 1}} } >
      <Image style={styles.profile_image} source = {require("./assets/Rewards.png")} />
      </Pressable>
      <Text style={styles.navtext}> Rewards </Text>      
    </View>

    <View style={styles.column}>
      <Pressable
       onPress={() => {Alert.alert("this will go to Town square")}}
       style={( {pressed} ) => 
       {return {opacity: pressed? 0.5 : 1}} } >
      <Image style={styles.profile_image} source = {require("./assets/Townsqaure.png")} />
      </Pressable>
      <Text style={styles.navtext}> Town Square </Text>      
    </View>


    <View style={styles.column}>
      <Pressable
       onPress={() => {Alert.alert("this will go to Activity Center")}}
       style={( {pressed} ) => 
       {return {opacity: pressed? 0.5 : 1}} } >
      <Image style={styles.profile_image} source = {require("./assets/ActivityCenter.png")} />
      </Pressable>
      <Text style={styles.navtext}> Activity Center </Text>      
    </View>

    
    <View style={styles.column}>
      <Pressable
       onPress={() => {Alert.alert("this will go to profile page")}}
       style={( {pressed} ) => 
       {return {opacity: pressed? 0.5 : 1}} } >
      <Image style={styles.profile_image} source = {require("./assets/profileimg.png")} />
      </Pressable>
      <Text style={styles.navtext}> Profile </Text>      
    </View>
    
    
    </View>
    </View>


    
  //</SafeAreaView>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    marginHorizontal: 16,
    
    
  },
  title: {
    textAlign: 'center',
    marginVertical: 8,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },

  column:{
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',       //THIS LINE HAS CHANGED
    paddingLeft: 10,
},

  row:{
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',       //THIS LINE HAS CHANGED
    paddingLeft: 9,

  },

  profile_image: {

    width :50,
    height:50
  },

  frameimage: {
    flex: 1,
    justifyContent: 'center',
  },

  blackbar: {
    zIndex: 2,
    position: 'absolute',
    backgroundColor: 'black',
    width: 400,
    height: 130,
    top: 650,
    left: 0,
    borderRadius: 20,

},
  navtext:{

    color: '#ffffff',


  },

  




});

export default App;